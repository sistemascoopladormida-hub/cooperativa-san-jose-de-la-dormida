-- Plantilla de datos de prueba (staging). Ajustar UUIDs tras crear usuarios en auth.users.
\set ON_ERROR_STOP on

-- Ejemplo de asignación de contexto (reemplazar UUIDs reales):
-- SELECT set_config('fp.test.proveedor_a', 'uuid-a', false);
-- SELECT set_config('fp.test.proveedor_b', 'uuid-b', false);
-- SELECT set_config('fp.test.compras', 'uuid-compras', false);

-- Bootstrap desarrollador (solo staging, con service role / postgres):
-- UPDATE public.fp_profiles SET role = 'desarrollador' WHERE id = 'uuid-dev';