-- Assertions RLS / RPC — requiere 01_seed.sql y auth.users reales en staging
\set ON_ERROR_STOP on

BEGIN;

DO $$
DECLARE
  v_proveedor_a UUID := NULLIF(current_setting('fp.test.proveedor_a', true), '')::UUID;
  v_proveedor_b UUID := NULLIF(current_setting('fp.test.proveedor_b', true), '')::UUID;
  v_count INTEGER;
BEGIN
  IF v_proveedor_a IS NULL OR v_proveedor_b IS NULL THEN
    RAISE NOTICE 'SKIP: configure fp.test.proveedor_a y fp.test.proveedor_b antes de ejecutar';
    RETURN;
  END IF;

  PERFORM set_config('request.jwt.claim.sub', v_proveedor_a::TEXT, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  SET LOCAL ROLE authenticated;

  SELECT COUNT(*) INTO v_count FROM public.fp_invoices i
  INNER JOIN public.fp_suppliers s ON s.id = i.supplier_id
  WHERE s.profile_id = v_proveedor_b;

  IF v_count > 0 THEN
    RAISE EXCEPTION 'FAIL: proveedor A ve facturas de B (% rows)', v_count;
  END IF;

  RAISE NOTICE 'PASS: proveedor A no ve facturas de B';
END $$;

DO $$
DECLARE
  v_compras UUID := NULLIF(current_setting('fp.test.compras', true), '')::UUID;
BEGIN
  IF v_compras IS NULL THEN
    RAISE NOTICE 'SKIP: fp.test.compras';
    RETURN;
  END IF;
  PERFORM set_config('request.jwt.claim.sub', v_compras::TEXT, true);
  SET LOCAL ROLE authenticated;
  BEGIN
    PERFORM public.fp_tesoreria_prepare_payment(
      gen_random_uuid(),
      CURRENT_DATE,
      1,
      'transferencia',
      v_compras,
      NULL,
      NULL
    );
    RAISE EXCEPTION 'FAIL: compras pudo preparar pago';
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'PASS: compras no puede preparar pago (%).', SQLERRM;
  END;
END $$;

-- Verificación estructural sin JWT (como postgres): bucket privado
DO $$
DECLARE
  v_public BOOLEAN;
BEGIN
  SELECT public INTO v_public FROM storage.buckets WHERE id = 'fp-documents';
  IF v_public IS DISTINCT FROM FALSE THEN
    RAISE EXCEPTION 'FAIL: bucket fp-documents debe ser privado';
  END IF;
  RAISE NOTICE 'PASS: bucket fp-documents es privado';
END $$;

ROLLBACK;